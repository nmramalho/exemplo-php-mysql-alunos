
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Aluno"],["c","Config"],["c","Escola"]];
